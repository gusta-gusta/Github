<html>
    <head>
        <title>Aula 6</title>
    </head>
<body>
        <?php

        require_once "Controlador.php";




        ?>

</body>

    </html>